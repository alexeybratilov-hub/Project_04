@echo off
chcp 65001 >nul
title OT-Baza Portable
start "" "%~dp0OT-Baza.exe"
exit
